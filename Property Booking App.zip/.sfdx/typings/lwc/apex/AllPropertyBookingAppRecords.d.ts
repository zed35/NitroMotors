declare module "@salesforce/apex/AllPropertyBookingAppRecords.getRecords" {
  export default function getRecords(param: {searchKey: any}): Promise<any>;
}
