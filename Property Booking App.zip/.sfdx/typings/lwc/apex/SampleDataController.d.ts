declare module "@salesforce/apex/SampleDataController.importSampleData" {
  export default function importSampleData(): Promise<any>;
}
