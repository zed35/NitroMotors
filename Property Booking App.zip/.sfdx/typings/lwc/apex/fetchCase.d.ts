declare module "@salesforce/apex/fetchCase.getCase" {
  export default function getCase(param: {searchKey: any}): Promise<any>;
}
