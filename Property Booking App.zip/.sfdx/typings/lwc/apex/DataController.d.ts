declare module "@salesforce/apex/DataController.fetchCase" {
  export default function fetchCase(param: {Search: any}): Promise<any>;
}
declare module "@salesforce/apex/DataController.fetchAccount" {
  export default function fetchAccount(param: {accId: any}): Promise<any>;
}
declare module "@salesforce/apex/DataController.fetchContact" {
  export default function fetchContact(param: {con: any}): Promise<any>;
}
