declare module "@salesforce/apex/fetchPropertyBooking.getPropBook" {
  export default function getPropBook(param: {recordId: any}): Promise<any>;
}
