declare module "@salesforce/apex/EmailTheQuotationDetailThenSetQuoteToYes.sendEmailNotification" {
  export default function sendEmailNotification(param: {qId: any}): Promise<any>;
}
declare module "@salesforce/apex/EmailTheQuotationDetailThenSetQuoteToYes.setQuoteToYes" {
  export default function setQuoteToYes(param: {qId: any}): Promise<any>;
}
