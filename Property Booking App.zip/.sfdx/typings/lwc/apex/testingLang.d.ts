declare module "@salesforce/apex/testingLang.getRecords" {
  export default function getRecords(param: {searchKey: any}): Promise<any>;
}
