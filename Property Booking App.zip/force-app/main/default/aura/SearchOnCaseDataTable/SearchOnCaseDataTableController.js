({
    
	handleApexData : function(component, event, helper) {
        
        var inputValue = event.getSource().get("v.value");
        component.set("v.inputValue", inputValue) 
        
		var action = component.get("c.getCase");
        action.setParams({
            searchKey : component.get("v.inputValue")
        });
		action.setCallback(this,function(resp){
							var currentState = resp.getState();
							if(currentState === "SUCCESS")
							{
								var caseData = resp.getReturnValue();
                                
                                caseData.forEach(caseRec => {
                                    if(caseRec.Id){
                                    	caseRec.CaseUrl = "https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Case/" + caseRec.Id + "/view";
                                	}
                    				if(caseRec.ContactId){
                        				caseRec.ContactName = caseRec.Contact.Name;
                                    	caseRec.ContactPhone = caseRec.Contact.Phone;
                                    	caseRec.ContactEmail = caseRec.Contact.Email;
                                    	caseRec.ContactUrl = "https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Contact/" + caseRec.ContactId + "/view";
                   					 }
                                                 
                    				if(caseRec.AccountId){
                        				caseRec.AccountName = caseRec.Account.Name;
                                    	caseRec.AccountPhone = caseRec.Account.Phone;
                                    	caseRec.AccountIndustry = caseRec.Account.Industry;
                                    	caseRec.AccountType = caseRec.Account.Type;
                                        caseRec.AccountUrl = "https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Account/" + caseRec.AccountId + "/view";
                    				}
                                
                					});
            
								component.set("v.cases",caseData);
                                
                            }
		});
        
        $A.enqueueAction(action);
        
        component.set("v.columns", [
            	{label:"Case Number", fieldName:"CaseUrl", type:"url", typeAttributes:{label:{fieldName:"CaseNumber"}, target: "_blank"}},
				{label:"Subject", fieldName:"Subject", type:"text"},
				{label:"Account Name", fieldName:"AccountUrl", type:"url", typeAttributes:{label:{fieldName:"AccountName"}, target: "_blank"}},
				{label:"Contact Name", fieldName:"ContactUrl", type:"url", typeAttributes:{label:{fieldName:"ContactName"}, target: "_blank"}}
			]);
        component.set("v.columns2", [
				{label:"Account Name", fieldName:"AccountUrl", type:"url", typeAttributes:{label:{fieldName:"AccountName"}, target: "_blank"}},
				{label:"Account Phone", fieldName:"AccountPhone"},
				{label:"Account Industry", fieldName:"AccountIndustry"},
				{label:"Account Type", fieldName:"AccountType"}
			]);
        
        component.set("v.columns3", [
				{label:"Contact Name", fieldName:"ContactUrl", type:"url", typeAttributes:{label:{fieldName:"ContactName"}, target: "_blank"}},
				{label:"Contact Phone", fieldName:"ContactPhone"},
				{label:"Contact Email", fieldName:"ContactEmail"},
				{label:"Account Name", fieldName:"AccountUrl", type:"url", typeAttributes:{label:{fieldName:"AccountName"}, target: "_blank"}}
			]);
        
	}
        
})