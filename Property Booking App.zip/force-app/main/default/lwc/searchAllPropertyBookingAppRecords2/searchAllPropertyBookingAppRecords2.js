import { LightningElement } from 'lwc';
import fetchCase from '@salesforce/apex/fetchCase.getCase';
import allPropertyBookingAppRecords from '@salesforce/apex/AllPropertyBookingAppRecords.getRecords';

const COLS_PROPERTYBOOKING = [   {
                                    label       : 'ID',
                                    fieldName   : 'PropertyBookingID',
                                    type        : 'text'
                                },
                                {
                                    label       : 'Property',
                                    fieldName   : 'PropertyName',
                                    type        : 'text'
                                },
                                {
                                    label       : 'Customer',
                                    fieldName   : 'CustomerName',
                                    type        : 'text'
                                },
                                {
                                    label       : 'Status',
                                    fieldName   : 'Status',
                                    type        : 'text'
                                },
                                {
                                    label       : 'Actual Price.',
                                    fieldName   : 'ActualPrice',
                                    type        : 'currency'
                                },
                                {
                                    label       : 'Quoted Price',
                                    fieldName   : 'QuotedPrice',
                                    type        : 'currency'
                                },
                                {
                                    label       : 'Quotation Generated',
                                    fieldName   : 'QuotationGenerated',
                                    type        : 'boolean'
                                },
                                {
                                    label           :   'Booking Reference',
                                    fieldName       :   'PropertyBookingURL',
                                    type            :   'url',
                                    typeAttributes  :   {
                                                        label : {
                                                                fieldName:'BookingReference'
                                                                }
                                                        }
                                },
                                {
                                    label       : 'Acquire Property By',
                                    fieldName   : 'AcquirePropertyBy',
                                    type        : 'date'
                                }
];
const colCase = [
    {label:"Case Number", fieldName:"CaseUrl", type:"url", typeAttributes:{label:{fieldName:"CaseNumber"}, target: "_blank"}},
    {label:"Subject", fieldName:"Subject", type:"text"},
    {label:"Account Name", fieldName:"AccountUrl", type:"url", typeAttributes:{label:{fieldName:"AccountName"}, target: "_blank"}},
    {label:"Contact Name", fieldName:"ContactUrl", type:"url", typeAttributes:{label:{fieldName:"ContactName"}, target: "_blank"}}
];
const colAccount = [
    {label:"Account Name", fieldName:"AccountUrl", type:"url", typeAttributes:{label:{fieldName:"AccountName"}, target: "_blank"}},
    {label:"Account Phone", fieldName:"AccountPhone"},
    {label:"Account Industry", fieldName:"AccountIndustry"},
    {label:"Account Type", fieldName:"AccountType"}
];

const colContact = [
    {label:"Contact Name", fieldName:"ContactUrl", type:"url", typeAttributes:{label:{fieldName:"ContactName"}, target: "_blank"}},
    {label:"Contact Phone", fieldName:"ContactPhone"},
    {label:"Contact Email", fieldName:"ContactEmail"},
    {label:"Account Name", fieldName:"AccountUrl", type:"url", typeAttributes:{label:{fieldName:"AccountName"}, target: "_blank"}}
];

export default class HOTS_Activity extends LightningElement {

columnsCase = colCase;
columnsAccount = colAccount;
columnsContact = colContact;
propertyColumn = COLS_PROPERTYBOOKING;
result2;
result;
error;
searchKey;
data;
handleKeys(e)
{
    this.searchKey = e.target.value;
    this.handleCaseData();
    this.handlePropertyBooking();
}

handleCaseData()
{

    

    fetchCase({'searchKey':this.searchKey}).then(res =>{

        let lastState = [];

        if(res){
            res.forEach(row =>{
                let recordFormat = {};
                recordFormat.CaseNumber = row.CaseNumber;
                recordFormat.Subject = row.Subject;
               
                if(recordFormat){
                    recordFormat.AccountName = row.Account.Name;
                    recordFormat.AccountPhone =  row.Account.Phone;
                    recordFormat.AccountIndustry =  row.Account.Industry;
                    recordFormat.AccountType =  row.Account.Type;
                    recordFormat.AccountUrl = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Account/'+ row.AccountId +'/view';
                    recordFormat.ContactName = row.Contact.Name;
                    recordFormat.ContactPhone = row.Contact.Phone;
                    recordFormat.ContactEmail = row.Contact.Email;
                    recordFormat.ContactUrl = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Contact/'+ row.ContactId +'/view';
                }
                recordFormat.CaseUrl = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Case/'+ row.Id +'/view';
                
                lastState.push(recordFormat);
            })

            this.result = lastState;

        }

    }).catch(err =>{

        this.error = err;

    })
    

}

handlePropertyBooking()
{

    allPropertyBookingAppRecords({'searchKey':this.searchKey}).then(res =>{

        let lastState = [];

        if(res){
            res.forEach(row =>{
                let recordFormat = {};
                recordFormat.id = row.Id;
                recordFormat.PropertyBookingID = row.ID__c;
                recordFormat.Status               = row.Status__c;
                recordFormat.ActualPrice          = row.Actual_Price__c;
                recordFormat.QuotedPrice          = row.Quoted_Price__c;
                recordFormat.QuotationGenerated   = row.Quotation_Generated__c;
                recordFormat.BookingReference     = row.Name;
                recordFormat.AcquirePropertyBy    = row.Acquire_Property_By__c;
                recordFormat.PropertyBookingURL   = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Property_Booking__c/'+row.Id+'/view';
                recordFormat.PropertyName     = row.Property__r.Name;
                recordFormat.PropertyURL      = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Property_List__c/'+row.Property__r.Id+'/view';
                recordFormat.CustomerName     = row.Customer__r.Name;
                recordFormat.CustomerURL      = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Customer_List__c/'+row.Customer__r.Id+'/view';
                

                lastState.push(recordFormat);
            })

            this.result2 = lastState;

        }

    }).catch(err =>{

        this.error = err;

    })
    

}

}