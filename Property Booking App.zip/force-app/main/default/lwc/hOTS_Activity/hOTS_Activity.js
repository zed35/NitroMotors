import { LightningElement } from 'lwc';

//import method from the Apex Class
import fetchCase from '@salesforce/apex/fetchCase.getCase';

//declaring the columns of the Case table
const colCase = [
    {label:"Case Number", fieldName:"CaseUrl", type:"url", typeAttributes:{label:{fieldName:"CaseNumber"}, target: "_blank"}},
    {label:"Subject", fieldName:"Subject", type:"text"},
    {label:"Account Name", fieldName:"AccountUrl", type:"url", typeAttributes:{label:{fieldName:"AccountName"}, target: "_blank"}},
    {label:"Contact Name", fieldName:"ContactUrl", type:"url", typeAttributes:{label:{fieldName:"ContactName"}, target: "_blank"}}
];
const colAccount = [
    {label:"Account Name", fieldName:"AccountUrl", type:"url", typeAttributes:{label:{fieldName:"AccountName"}, target: "_blank"}},
    {label:"Account Phone", fieldName:"AccountPhone"},
    {label:"Account Industry", fieldName:"AccountIndustry"},
    {label:"Account Type", fieldName:"AccountType"}
];

const colContact = [
    {label:"Contact Name", fieldName:"ContactUrl", type:"url", typeAttributes:{label:{fieldName:"ContactName"}, target: "_blank"}},
    {label:"Contact Phone", fieldName:"ContactPhone"},
    {label:"Contact Email", fieldName:"ContactEmail"},
    {label:"Account Name", fieldName:"AccountUrl", type:"url", typeAttributes:{label:{fieldName:"AccountName"}, target: "_blank"}}
];

export default class HOTS_Activity extends LightningElement {

columnsCase = colCase;
columnsAccount = colAccount;
columnsContact = colContact;
result;
error;
searchKey;
data;
handleKeys(e)
{
    this.searchKey = e.target.value;
    this.handleCaseData();
}

handleCaseData()
{

    

    fetchCase({'searchKey':this.searchKey}).then(res =>{

        let lastState = [];

        if(res){
            res.forEach(row =>{
                let recordFormat = {};
                recordFormat.CaseNumber = row.CaseNumber;
                recordFormat.Subject = row.Subject;
               
                if(recordFormat){
                    recordFormat.AccountName = row.Account.Name;
                    recordFormat.AccountPhone =  row.Account.Phone;
                    recordFormat.AccountIndustry =  row.Account.Industry;
                    recordFormat.AccountType =  row.Account.Type;
                    recordFormat.AccountUrl = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Account/'+ row.AccountId +'/view';
                    recordFormat.ContactName = row.Contact.Name;
                    recordFormat.ContactPhone = row.Contact.Phone;
                    recordFormat.ContactEmail = row.Contact.Email;
                    recordFormat.ContactUrl = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Contact/'+ row.ContactId +'/view';
                }
                recordFormat.CaseUrl = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Case/'+ row.Id +'/view';
                
                lastState.push(recordFormat);
                console.log(row.Account.Name);
            })

            this.result = lastState;

        }

    }).catch(err =>{

        this.error = err;

    })
    

}

}