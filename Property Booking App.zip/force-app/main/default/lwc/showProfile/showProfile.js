import { LightningElement } from 'lwc';
import PHOTO from '@salesforce/resourceUrl/credit';

const column = [
    { label: 'SR#', fieldName: 'rowNumber',type:'text'},
    { label: 'Profile Pic', fieldName: 'profile_image', type:'image'},
    { label: 'Member Name', fieldName: 'display_name' },
    { label: 'Website', fieldName: 'website_url' , type:'url'},
    { label: 'Reputation', fieldName: 'reputation' },
    { label: 'Gold Badge', fieldName: 'gold', type:'text',cellAttributes: { class: 'slds-text-color_error slds-text-title_bold'}},
    { label: 'Silver Badge', fieldName: 'silver', type:'text',cellAttributes: { class: 'slds-text-color_warning slds-text-title_bold'}},
    { label: 'Bronze Badge', fieldName: 'bronze' , type:'text',cellAttributes: { class: 'slds-text-color_success slds-text-title_bold'}},
    { label: 'Is Employee', fieldName: 'is_employee' },
    { label: 'Created Date', fieldName: 'date', type: "date",
    typeAttributes:{
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
    }},
];

const entry = [{
        rowNumber: "1",
        profile_image: PHOTO + '/credit.jpg',
        display_name: 'Cardo Dalisay',
        website_url: 'www.google.com',
        reputation: '999999',
        gold: '99',
        silver: '99',
        bronze: '99',
        is_employee: 'True',
        date: '2012-12-12'
}];

export default class ShowProfile extends LightningElement {

data = entry;
columns = column;

}