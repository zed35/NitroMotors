import { LightningElement, api, wire } from 'lwc';
import sendQuote from '@salesforce/apex/EmailTheQuotationDetailThenSetQuoteToYes.sendEmailNotification'
import setQuoteToYes from '@salesforce/apex/EmailTheQuotationDetailThenSetQuoteToYes.setQuoteToYes';

export default class SendQuotation extends LightningElement {

@api recordId

@api 
invoke(){

    sendQuote({'qId' : this.recordId})
    .then(() =>{

        setQuoteToYes({'qId' : this.recordId});
        console.log('successful');

    }).catch(error =>{

        console.log(this.recordId);
        console.log(error);

    });

    }

}