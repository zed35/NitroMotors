import { LightningElement } from 'lwc';
import allPropertyBookingAppRecords from '@salesforce/apex/AllPropertyBookingAppRecords.getRecords';
import { refreshApex } from '@salesforce/apex';

const COLS_PROPERTY = [  {
                            label       : 'ID',
                            fieldName   : 'PropID',
                            type        : 'text'
                        },
                        {
                            label           :   'Property No.',
                            fieldName       :   'PropertyURL',
                            type            :   'url',
                            typeAttributes  :   {
                                                label : {
                                                        fieldName:'PropertyNumber',
                                                        target: "_blank"
                                                        }
                                                }
                        },
                        {
                            label       : 'Property Name',
                            fieldName   : 'PropertyName',
                            type        : 'text'
                        },
                        {
                            label       : 'State',
                            fieldName   : 'PropState',
                            type        : 'text'
                        },
                        {
                            label       : 'District',
                            fieldName   : 'PropDistrict',
                            type        : 'text'
                        },
                        {
                            label       : 'Storey',
                            fieldName   : 'Storey',
                            type        : 'text'
                        },
                        {
                            label       : 'Type',
                            fieldName   : 'Type',
                            type        : 'text'
                        },
                        {
                            label       : 'Built on',
                            fieldName   : 'BuiltOn',
                            type        : 'date'
                        },
                        {
                            label       : 'Property Age',
                            fieldName   : 'PropertyAge',
                            type        : 'text'
                        },
                        {
                            label       : 'Need Renovation',
                            fieldName   : 'NeedRenovation',
                            type        :  'boolean'
                        }
];

const COLS_CUSTOMER = [  {
                            label       : 'ID',
                            fieldName   : 'CustID',
                            type        : 'text'
                        },
                        {
                            label       : 'User',
                            fieldName   : 'User',
                            type        : 'text'
                        },
                        {
                            label           :   'Customer Name',
                            fieldName       :   'CustomerURL',
                            type            :   'url',
                            typeAttributes  :   {
                                                label : {
                                                        fieldName:'CustomerName',
                                                        target: "_blank"
                                                        }
                                                }
                        },
                        {
                            label       : 'Aadhar',
                            fieldName   : 'Aadhar',
                            type        : 'text'
                        },
                        {
                            label       : 'PAN',
                            fieldName   : 'PAN',
                            type        : 'text'
                        },
                        {
                            label       : 'State',
                            fieldName   : 'CustState',
                            type        : 'text'
                        },
                        {
                            label       : 'District',
                            fieldName   : 'CustDistrict',
                            type        : 'text'
                        },
                        {
                            label       : 'Email',
                            fieldName   : 'Email',
                            type        : 'email'
                        },
                        {
                            label       : 'Phone',
                            fieldName   : 'Phone',
                            type        : 'phone'
                        }
                        
];

const COLS_PROPERTYBOOKING = [   {
                                    label       : 'ID',
                                    fieldName   : 'PropertyBookingID',
                                    type        : 'text'
                                },
                                {
                                    label           :   'Property Name',
                                    fieldName       :   'PropertyName',
                                    type            :   'text',
                                },
                                {
                                    label           :   'Customer Name',
                                    fieldName       :   'CustomerURL',
                                    type            :   'url',
                                    typeAttributes  :   {
                                                        label : {
                                                                fieldName:'CustomerName',
                                                                target: "_blank"
                                                                }
                                                        }
                                },
                                {
                                    label       : 'Status',
                                    fieldName   : 'Status',
                                    type        : 'text'
                                },
                                {
                                    label       : 'Actual Price.',
                                    fieldName   : 'ActualPrice',
                                    type        : 'currency'
                                },
                                {
                                    label       : 'Quoted Price',
                                    fieldName   : 'QuotedPrice',
                                    type        : 'currency'
                                },
                                {
                                    label       : 'Quotation Generated',
                                    fieldName   : 'QuotationGenerated',
                                    type        : 'boolean'
                                },
                                {
                                    label           :   'Booking Reference',
                                    fieldName       :   'PropertyBookingURL',
                                    type            :   'url',
                                    typeAttributes  :   {
                                                        label : {
                                                                fieldName:'BookingReference',
                                                                target: "_blank"
                                                                }
                                                        }
                                },
                                {
                                    label       : 'Acquire Property By',
                                    fieldName   : 'AcquirePropertyBy',
                                    type        : 'date'
                                }
];

const COLS_QUOTATION = [ {
                            label           :   'Quote No.',
                            fieldName       :   'QuotationURL',
                            type            :   'url',
                            typeAttributes  :   {
                                                label : {
                                                        fieldName:'QuoteNo',
                                                        target: "_blank"
                                                        }
                                                }
                        },
                        {
                            label           :   'Booking Reference',
                            fieldName       :   'PropertyBookingURL',
                            type            :   'url',
                            typeAttributes  :   {
                                                label : {
                                                        fieldName:'BookingReference',
                                                        target: "_blank"
                                                        }
                                                }
                        },
                        {
                            label       : 'Property Name',
                            fieldName   : 'QuotationPropertyName',
                            type        : 'text'
                        },
                        {
                            label       : 'Property Type',
                            fieldName   : 'QuotationPropertyType',
                            type        : 'text'
                        },
                        {
                            label           :   'Customer Name',
                            fieldName       :   'CustomerURL',
                            type            :   'url',
                            typeAttributes  :   {
                                                label : {
                                                        fieldName:'CustomerName',
                                                        target: "_blank"
                                                        }
                                                }
                        },
                        {
                            label       : 'Acquire Property By',
                            fieldName   : 'QuotationAcquirePropertyBy',
                            type        : 'date'
                        },
                        {
                            label       : 'Price',
                            fieldName   : 'QuotationPrice',
                            type        : 'currency'
                        },
                        {
                            label       : 'Quoted to Customer',
                            fieldName   : 'QuotedToCustomer',
                            type        : 'boolean'
                        },
                        {
                            label       : 'Customer Email',
                            fieldName   : 'QuotationCustomerEmail',
                            type        : 'email'
                        }
];  

export default class SearchAllPropertyBookingAppRecords extends LightningElement {

propertyColumn = COLS_PROPERTY;
customerColumn = COLS_CUSTOMER;
propertyBookingColumn = COLS_PROPERTYBOOKING;
quotationColumn = COLS_QUOTATION;

propertyBookingData;
propertyData;
customerData;
quotationData;

error;
searchKey;

handleKeys(event){
    this.searchKey = event.target.value;
    this.handlePropertyBooking();
    this.handleProperty();
    this.handleCustomer();
    this.handleQuotation();
    if (this.searchKey === ""){
        this.searchKey = null;
        this.propertyBookingData.splice(0, this.propertyBookingData.length);
        this.propertyData.splice(0, this.propertyData.length);
        this.customerData.splice(0, this.customerData.length);
        this.quotationData.splice(0, this.quotationData.length);
        this.refreshData();
        console.log(this.propertyBookingData);
    }
}

handlePropertyBooking(){
    allPropertyBookingAppRecords({'searchKey' : this.searchKey})
    .then(data =>{
        let captureStruct = [];
        if(data){ 
            data.forEach(field =>{
                let struct = {};
                
                struct.id                   = field.Id;
                struct.PropertyBookingID    = field.ID__c;
                struct.Status               = field.Status__c;
                struct.ActualPrice          = field.Actual_Price__c;
                struct.QuotedPrice          = field.Quoted_Price__c;
                struct.QuotationGenerated   = field.Quotation_Generated__c;
                struct.BookingReference     = field.Name;
                struct.AcquirePropertyBy    = field.Acquire_Property_By__c;
                struct.PropertyBookingURL   = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Property_Booking__c/'+field.Id+'/view';
                struct.PropertyName         = field.Property__r.Name
                struct.CustomerName         = field.Customer__r.Name;
                struct.CustomerURL          = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Customer_List__c/'+field.Customer__r.Id+'/view';
                
                captureStruct.push(struct);
            });
            this.propertyBookingData = captureStruct;
        }
    }).catch(err=>{
        this.error = err;
    });
}

handleProperty(){
    allPropertyBookingAppRecords({'searchKey' : this.searchKey})
    .then(data =>{
        let captureStruct = [];
        if(data){ 
            data.forEach(field =>{
                let struct = {};
                
                struct.PropID           = field.Property__r.ID__c;
                struct.PropertyNumber   = field.Property__r.Property__c;
                struct.PropertyName     = field.Property__r.Name;
                struct.PropState        = field.Property__r.State__c;
                struct.PropDistrict     = field.Property__r.District__c;
                struct.Storey           = field.Property__r.Storey__c;
                struct.Type             = field.Property__r.Type__c;
                struct.BuiltOn          = field.Property__r.Built_on__c;
                struct.PropertyAge      = field.Property__r.Property_Age_Years__c;
                struct.NeedRenovation   = field.Property__r.Needs_Renovation__c;
                struct.PropertyURL      = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Property_List__c/'+field.Property__r.Id+'/view';

                
                captureStruct.push(struct);
            });
            this.propertyData = captureStruct;
        }
    }).catch(err=>{
        this.error = err;
    });
}

handleCustomer(){
    allPropertyBookingAppRecords({'searchKey' : this.searchKey})
    .then(data =>{
        let captureStruct = [];
        if(data){ 
            data.forEach(field =>{
                let struct = {};
                
                struct.CustID           = field.Customer__r.ID__c;
                struct.User             = field.Customer__r.User__r.Name;
                struct.CustomerName     = field.Customer__r.Name;
                struct.Aadhar           = field.Customer__r.Aadhar__c;
                struct.PAN              = field.Customer__r.PAN__c;
                struct.CustState        = field.Customer__r.State__c;
                struct.CustDistrict     = field.Customer__r.District__c;
                struct.Email            = field.Customer__r.Email__c;
                struct.Phone            = field.Customer__r.Phone__c;
                struct.CustomerURL      = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Customer_List__c/'+field.Customer__r.Id+'/view';
                
                captureStruct.push(struct);
            });
            this.customerData = captureStruct;
        }
    }).catch(err=>{
        this.error = err;
    });
}

handleQuotation(){

    allPropertyBookingAppRecords({'searchKey' : this.searchKey})
    .then(data =>{
            let captureStruct = [];
            if(data){ 
                data.forEach(field =>{
                    let struct = {};

                    field.Quotations__r.forEach(field2 =>{
                        struct.QuoteNo                      = field2.Name;
                        struct.QuotationPropertyName        = field2.Property_Name__c;
                        struct.QuotationPropertyType        = field2.Property_Type__c;
                        struct.QuotationCustomerName        = field2.Customer_Name__c;
                        struct.QuotationAcquirePropertyBy   = field2.Acquire_Property_By__c;
                        struct.QuotationPrice               = field2.Price__c;
                        struct.QuotedToCustomer             = field2.Quoted_to_Customer__c;
                        struct.QuotationCustomerEmail       = field2.Customer_Email__c;
                        struct.QuotationURL                 = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Quotation__c/'+field2.Id+'/view';
                    });
        
                    struct.CustomerName                 = field.Customer__r.Name;
                    struct.CustomerURL                  = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Customer_List__c/'+field.Customer__r.Id+'/view';
                    struct.PropertyNumber               = field.Property__r.Property__c;
                    struct.PropertyURL                  = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Property_List__c/'+field.Property__r.Id+'/view';
                    struct.BookingReference             = field.Name;
                    struct.PropertyBookingURL           = 'https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Property_Booking__c/'+field.Id+'/view';

                    captureStruct.push(struct);
                })
                this.quotationData = captureStruct;
            }
        }).catch(err=>{
            this.error = err;
        });

    }


    refreshData(){
        return refreshApex(this.propertyBookingData, this.propertyData, this.customerData, this.quotationData);
    }

}