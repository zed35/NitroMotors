import { LightningElement, wire, api } from 'lwc';
import quotationId from '@salesforce/apex/fetchPropertyBooking.getPropBook';

export default class OpenQuotation extends LightningElement {

@api recordId

result;
data;

@wire(quotationId, {recordId :'$recordId'})
getPropBook({error,data})
{
    if (data){
        this.result = data;
        this.error = undefined;
        console.log(this.result);
    }
    else
    {
        this.error = error;
        this.error = undefined;
    }
}

@api invoke(){
    window.open('https://collabera-aa-dev-ed.lightning.force.com/lightning/r/Quotation__c/'+ this.result +'/view');
}

}