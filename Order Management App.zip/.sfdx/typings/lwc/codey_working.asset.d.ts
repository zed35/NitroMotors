declare module "@salesforce/contentAssetUrl/codey_working" {
    var codey_working: string;
    export default codey_working;
}