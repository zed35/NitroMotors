declare module "@salesforce/resourceUrl/banner" {
    var banner: string;
    export default banner;
}