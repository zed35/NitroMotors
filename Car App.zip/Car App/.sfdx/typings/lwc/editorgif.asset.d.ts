declare module "@salesforce/contentAssetUrl/editorgif" {
    var editorgif: string;
    export default editorgif;
}