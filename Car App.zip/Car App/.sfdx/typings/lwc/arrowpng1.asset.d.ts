declare module "@salesforce/contentAssetUrl/arrowpng1" {
    var arrowpng1: string;
    export default arrowpng1;
}