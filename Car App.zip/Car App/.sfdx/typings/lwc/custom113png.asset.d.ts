declare module "@salesforce/contentAssetUrl/custom113png" {
    var custom113png: string;
    export default custom113png;
}