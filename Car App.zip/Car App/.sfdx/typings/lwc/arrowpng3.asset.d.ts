declare module "@salesforce/contentAssetUrl/arrowpng3" {
    var arrowpng3: string;
    export default arrowpng3;
}