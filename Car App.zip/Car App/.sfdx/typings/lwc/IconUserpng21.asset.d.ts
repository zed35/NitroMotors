declare module "@salesforce/contentAssetUrl/IconUserpng21" {
    var IconUserpng21: string;
    export default IconUserpng21;
}