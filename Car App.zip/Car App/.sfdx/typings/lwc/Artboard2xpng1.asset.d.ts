declare module "@salesforce/contentAssetUrl/Artboard2xpng1" {
    var Artboard2xpng1: string;
    export default Artboard2xpng1;
}