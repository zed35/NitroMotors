declare module "@salesforce/contentAssetUrl/iconconditionalpng" {
    var iconconditionalpng: string;
    export default iconconditionalpng;
}