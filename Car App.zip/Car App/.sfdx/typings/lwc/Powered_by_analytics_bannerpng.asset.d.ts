declare module "@salesforce/contentAssetUrl/Powered_by_analytics_bannerpng" {
    var Powered_by_analytics_bannerpng: string;
    export default Powered_by_analytics_bannerpng;
}