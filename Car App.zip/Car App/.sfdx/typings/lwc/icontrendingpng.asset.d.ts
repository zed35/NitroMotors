declare module "@salesforce/contentAssetUrl/icontrendingpng" {
    var icontrendingpng: string;
    export default icontrendingpng;
}