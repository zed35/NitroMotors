declare module "@salesforce/contentAssetUrl/custom109png3" {
    var custom109png3: string;
    export default custom109png3;
}