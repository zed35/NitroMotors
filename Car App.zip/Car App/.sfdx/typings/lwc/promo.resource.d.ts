declare module "@salesforce/resourceUrl/promo" {
    var promo: string;
    export default promo;
}