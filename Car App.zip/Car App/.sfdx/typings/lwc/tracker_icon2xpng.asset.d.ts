declare module "@salesforce/contentAssetUrl/tracker_icon2xpng" {
    var tracker_icon2xpng: string;
    export default tracker_icon2xpng;
}