declare module "@salesforce/contentAssetUrl/IconUserpng31" {
    var IconUserpng31: string;
    export default IconUserpng31;
}