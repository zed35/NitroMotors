declare module "@salesforce/contentAssetUrl/manufacturing_app_iconpng3" {
    var manufacturing_app_iconpng3: string;
    export default manufacturing_app_iconpng3;
}