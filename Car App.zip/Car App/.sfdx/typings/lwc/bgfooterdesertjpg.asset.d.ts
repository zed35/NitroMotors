declare module "@salesforce/contentAssetUrl/bgfooterdesertjpg" {
    var bgfooterdesertjpg: string;
    export default bgfooterdesertjpg;
}