declare module "@salesforce/resourceUrl/SNA_Badger_Parts_Partner_Community1_sf_default_cdn_WA2xr" {
    var SNA_Badger_Parts_Partner_Community1_sf_default_cdn_WA2xr: string;
    export default SNA_Badger_Parts_Partner_Community1_sf_default_cdn_WA2xr;
}