declare module "@salesforce/contentAssetUrl/customerspng3" {
    var customerspng3: string;
    export default customerspng3;
}