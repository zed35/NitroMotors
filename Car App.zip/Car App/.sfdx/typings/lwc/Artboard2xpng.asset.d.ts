declare module "@salesforce/contentAssetUrl/Artboard2xpng" {
    var Artboard2xpng: string;
    export default Artboard2xpng;
}