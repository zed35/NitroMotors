declare module "@salesforce/contentAssetUrl/iconlocationpng" {
    var iconlocationpng: string;
    export default iconlocationpng;
}