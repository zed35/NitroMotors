declare module "@salesforce/contentAssetUrl/icondbppng" {
    var icondbppng: string;
    export default icondbppng;
}