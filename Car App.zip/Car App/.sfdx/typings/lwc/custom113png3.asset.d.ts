declare module "@salesforce/contentAssetUrl/custom113png3" {
    var custom113png3: string;
    export default custom113png3;
}