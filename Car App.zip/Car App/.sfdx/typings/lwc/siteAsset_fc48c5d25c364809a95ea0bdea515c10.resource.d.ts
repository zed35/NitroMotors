declare module "@salesforce/resourceUrl/siteAsset_fc48c5d25c364809a95ea0bdea515c10" {
    var siteAsset_fc48c5d25c364809a95ea0bdea515c10: string;
    export default siteAsset_fc48c5d25c364809a95ea0bdea515c10;
}