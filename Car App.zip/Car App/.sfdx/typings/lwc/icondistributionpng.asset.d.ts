declare module "@salesforce/contentAssetUrl/icondistributionpng" {
    var icondistributionpng: string;
    export default icondistributionpng;
}