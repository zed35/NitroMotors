declare module "@salesforce/contentAssetUrl/iconintroductionpng" {
    var iconintroductionpng: string;
    export default iconintroductionpng;
}