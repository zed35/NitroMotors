declare module "@salesforce/contentAssetUrl/astro_hmmmpng" {
    var astro_hmmmpng: string;
    export default astro_hmmmpng;
}