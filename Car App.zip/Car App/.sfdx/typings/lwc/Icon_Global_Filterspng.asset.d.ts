declare module "@salesforce/contentAssetUrl/Icon_Global_Filterspng" {
    var Icon_Global_Filterspng: string;
    export default Icon_Global_Filterspng;
}