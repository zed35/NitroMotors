declare module "@salesforce/contentAssetUrl/custom113png2" {
    var custom113png2: string;
    export default custom113png2;
}