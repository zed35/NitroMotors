declare module "@salesforce/resourceUrl/showroom_img" {
    var showroom_img: string;
    export default showroom_img;
}