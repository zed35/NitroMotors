declare module "@salesforce/contentAssetUrl/headerdetailpng" {
    var headerdetailpng: string;
    export default headerdetailpng;
}