declare module "@salesforce/contentAssetUrl/money_bag_png1" {
    var money_bag_png1: string;
    export default money_bag_png1;
}