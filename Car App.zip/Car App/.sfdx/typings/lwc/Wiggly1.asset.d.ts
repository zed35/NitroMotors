declare module "@salesforce/contentAssetUrl/Wiggly1" {
    var Wiggly1: string;
    export default Wiggly1;
}