declare module "@salesforce/contentAssetUrl/manufacturing_app_iconpng" {
    var manufacturing_app_iconpng: string;
    export default manufacturing_app_iconpng;
}