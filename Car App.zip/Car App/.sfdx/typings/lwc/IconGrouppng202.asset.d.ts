declare module "@salesforce/contentAssetUrl/IconGrouppng202" {
    var IconGrouppng202: string;
    export default IconGrouppng202;
}