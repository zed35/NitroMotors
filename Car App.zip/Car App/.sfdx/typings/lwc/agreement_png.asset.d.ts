declare module "@salesforce/contentAssetUrl/agreement_png" {
    var agreement_png: string;
    export default agreement_png;
}