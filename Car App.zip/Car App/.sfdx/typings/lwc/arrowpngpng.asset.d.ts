declare module "@salesforce/contentAssetUrl/arrowpngpng" {
    var arrowpngpng: string;
    export default arrowpngpng;
}