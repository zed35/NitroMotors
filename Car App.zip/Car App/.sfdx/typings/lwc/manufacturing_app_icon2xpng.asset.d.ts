declare module "@salesforce/contentAssetUrl/manufacturing_app_icon2xpng" {
    var manufacturing_app_icon2xpng: string;
    export default manufacturing_app_icon2xpng;
}