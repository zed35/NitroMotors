declare module "@salesforce/contentAssetUrl/X360" {
    var X360: string;
    export default X360;
}