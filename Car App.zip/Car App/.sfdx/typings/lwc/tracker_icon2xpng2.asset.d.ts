declare module "@salesforce/contentAssetUrl/tracker_icon2xpng2" {
    var tracker_icon2xpng2: string;
    export default tracker_icon2xpng2;
}