declare module "@salesforce/contentAssetUrl/custom109png2" {
    var custom109png2: string;
    export default custom109png2;
}