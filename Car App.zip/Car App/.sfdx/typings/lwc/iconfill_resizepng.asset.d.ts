declare module "@salesforce/contentAssetUrl/iconfill_resizepng" {
    var iconfill_resizepng: string;
    export default iconfill_resizepng;
}