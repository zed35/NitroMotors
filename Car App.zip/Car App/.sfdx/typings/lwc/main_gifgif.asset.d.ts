declare module "@salesforce/contentAssetUrl/main_gifgif" {
    var main_gifgif: string;
    export default main_gifgif;
}