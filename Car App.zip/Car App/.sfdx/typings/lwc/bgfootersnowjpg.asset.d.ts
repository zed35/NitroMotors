declare module "@salesforce/contentAssetUrl/bgfootersnowjpg" {
    var bgfootersnowjpg: string;
    export default bgfootersnowjpg;
}