declare module "@salesforce/contentAssetUrl/graph2xpng2" {
    var graph2xpng2: string;
    export default graph2xpng2;
}