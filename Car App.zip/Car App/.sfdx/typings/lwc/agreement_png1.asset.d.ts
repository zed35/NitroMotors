declare module "@salesforce/contentAssetUrl/agreement_png1" {
    var agreement_png1: string;
    export default agreement_png1;
}