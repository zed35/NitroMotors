declare module "@salesforce/contentAssetUrl/iconfilterpng" {
    var iconfilterpng: string;
    export default iconfilterpng;
}