declare module "@salesforce/resourceUrl/siteAsset_e7ae2dcab74f4df4869e662be5bca368" {
    var siteAsset_e7ae2dcab74f4df4869e662be5bca368: string;
    export default siteAsset_e7ae2dcab74f4df4869e662be5bca368;
}