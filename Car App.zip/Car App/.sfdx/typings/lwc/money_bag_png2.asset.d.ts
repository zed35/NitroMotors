declare module "@salesforce/contentAssetUrl/money_bag_png2" {
    var money_bag_png2: string;
    export default money_bag_png2;
}