declare module "@salesforce/contentAssetUrl/icontimeseriespng" {
    var icontimeseriespng: string;
    export default icontimeseriespng;
}