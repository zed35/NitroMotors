declare module "@salesforce/contentAssetUrl/graph2xpng" {
    var graph2xpng: string;
    export default graph2xpng;
}