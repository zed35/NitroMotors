declare module "@salesforce/contentAssetUrl/iconmappng" {
    var iconmappng: string;
    export default iconmappng;
}