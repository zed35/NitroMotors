declare module "@salesforce/contentAssetUrl/IconGrouppng201" {
    var IconGrouppng201: string;
    export default IconGrouppng201;
}