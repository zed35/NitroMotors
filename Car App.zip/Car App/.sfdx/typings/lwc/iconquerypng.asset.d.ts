declare module "@salesforce/contentAssetUrl/iconquerypng" {
    var iconquerypng: string;
    export default iconquerypng;
}