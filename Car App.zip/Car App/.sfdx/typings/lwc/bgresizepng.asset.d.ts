declare module "@salesforce/contentAssetUrl/bgresizepng" {
    var bgresizepng: string;
    export default bgresizepng;
}