declare module "@salesforce/contentAssetUrl/iconcompositionpng" {
    var iconcompositionpng: string;
    export default iconcompositionpng;
}