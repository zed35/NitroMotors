declare module "@salesforce/contentAssetUrl/metrics_png3" {
    var metrics_png3: string;
    export default metrics_png3;
}