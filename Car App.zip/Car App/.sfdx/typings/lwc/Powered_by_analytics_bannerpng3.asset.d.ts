declare module "@salesforce/contentAssetUrl/Powered_by_analytics_bannerpng3" {
    var Powered_by_analytics_bannerpng3: string;
    export default Powered_by_analytics_bannerpng3;
}