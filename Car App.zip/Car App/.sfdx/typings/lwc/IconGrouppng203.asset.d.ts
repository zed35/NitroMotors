declare module "@salesforce/contentAssetUrl/IconGrouppng203" {
    var IconGrouppng203: string;
    export default IconGrouppng203;
}