declare module "@salesforce/resourceUrl/footer" {
    var footer: string;
    export default footer;
}