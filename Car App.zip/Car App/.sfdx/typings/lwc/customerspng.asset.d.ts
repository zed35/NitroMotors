declare module "@salesforce/contentAssetUrl/customerspng" {
    var customerspng: string;
    export default customerspng;
}