declare module "@salesforce/contentAssetUrl/IconGrouppng191" {
    var IconGrouppng191: string;
    export default IconGrouppng191;
}