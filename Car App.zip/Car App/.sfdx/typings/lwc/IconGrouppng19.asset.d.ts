declare module "@salesforce/contentAssetUrl/IconGrouppng19" {
    var IconGrouppng19: string;
    export default IconGrouppng19;
}