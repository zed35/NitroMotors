declare module "@salesforce/contentAssetUrl/logo2" {
    var logo2: string;
    export default logo2;
}