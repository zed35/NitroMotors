declare module "@salesforce/contentAssetUrl/customerspng1" {
    var customerspng1: string;
    export default customerspng1;
}