declare module "@salesforce/contentAssetUrl/IconUserpng2" {
    var IconUserpng2: string;
    export default IconUserpng2;
}