declare module "@salesforce/resourceUrl/customize" {
    var customize: string;
    export default customize;
}