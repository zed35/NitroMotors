declare module "@salesforce/contentAssetUrl/logo3" {
    var logo3: string;
    export default logo3;
}