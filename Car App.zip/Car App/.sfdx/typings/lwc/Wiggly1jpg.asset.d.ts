declare module "@salesforce/contentAssetUrl/Wiggly1jpg" {
    var Wiggly1jpg: string;
    export default Wiggly1jpg;
}