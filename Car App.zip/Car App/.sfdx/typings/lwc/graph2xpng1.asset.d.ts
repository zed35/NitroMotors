declare module "@salesforce/contentAssetUrl/graph2xpng1" {
    var graph2xpng1: string;
    export default graph2xpng1;
}