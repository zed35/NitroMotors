declare module "@salesforce/contentAssetUrl/manufacturing_app_icon2xpng2" {
    var manufacturing_app_icon2xpng2: string;
    export default manufacturing_app_icon2xpng2;
}