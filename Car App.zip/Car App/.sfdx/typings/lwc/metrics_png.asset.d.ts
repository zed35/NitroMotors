declare module "@salesforce/contentAssetUrl/metrics_png" {
    var metrics_png: string;
    export default metrics_png;
}