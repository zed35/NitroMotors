declare module "@salesforce/contentAssetUrl/manufacturing_app_iconpng1" {
    var manufacturing_app_iconpng1: string;
    export default manufacturing_app_iconpng1;
}