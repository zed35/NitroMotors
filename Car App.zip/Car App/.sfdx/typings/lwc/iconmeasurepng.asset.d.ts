declare module "@salesforce/contentAssetUrl/iconmeasurepng" {
    var iconmeasurepng: string;
    export default iconmeasurepng;
}