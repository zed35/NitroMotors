declare module "@salesforce/contentAssetUrl/arrowpng" {
    var arrowpng: string;
    export default arrowpng;
}