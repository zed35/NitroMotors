declare module "@salesforce/contentAssetUrl/metrics_png1" {
    var metrics_png1: string;
    export default metrics_png1;
}