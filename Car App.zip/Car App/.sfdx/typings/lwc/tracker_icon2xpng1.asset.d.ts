declare module "@salesforce/contentAssetUrl/tracker_icon2xpng1" {
    var tracker_icon2xpng1: string;
    export default tracker_icon2xpng1;
}