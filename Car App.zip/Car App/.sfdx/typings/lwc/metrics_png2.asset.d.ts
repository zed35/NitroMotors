declare module "@salesforce/contentAssetUrl/metrics_png2" {
    var metrics_png2: string;
    export default metrics_png2;
}