declare module "@salesforce/contentAssetUrl/tracker_icon2xpng3" {
    var tracker_icon2xpng3: string;
    export default tracker_icon2xpng3;
}