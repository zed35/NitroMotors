declare module "@salesforce/contentAssetUrl/Icon_userpng1" {
    var Icon_userpng1: string;
    export default Icon_userpng1;
}