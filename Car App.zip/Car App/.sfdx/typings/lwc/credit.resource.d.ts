declare module "@salesforce/resourceUrl/credit" {
    var credit: string;
    export default credit;
}