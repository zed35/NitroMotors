declare module "@salesforce/contentAssetUrl/Icon_grouppng" {
    var Icon_grouppng: string;
    export default Icon_grouppng;
}