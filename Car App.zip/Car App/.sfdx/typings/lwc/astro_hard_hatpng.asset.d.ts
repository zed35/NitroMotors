declare module "@salesforce/contentAssetUrl/astro_hard_hatpng" {
    var astro_hard_hatpng: string;
    export default astro_hard_hatpng;
}