declare module "@salesforce/contentAssetUrl/iconlimitpng" {
    var iconlimitpng: string;
    export default iconlimitpng;
}