declare module "@salesforce/contentAssetUrl/findeditorgif" {
    var findeditorgif: string;
    export default findeditorgif;
}