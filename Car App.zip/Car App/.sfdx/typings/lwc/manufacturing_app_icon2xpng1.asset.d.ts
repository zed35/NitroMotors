declare module "@salesforce/contentAssetUrl/manufacturing_app_icon2xpng1" {
    var manufacturing_app_icon2xpng1: string;
    export default manufacturing_app_icon2xpng1;
}