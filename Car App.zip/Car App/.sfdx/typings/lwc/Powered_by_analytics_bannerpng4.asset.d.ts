declare module "@salesforce/contentAssetUrl/Powered_by_analytics_bannerpng4" {
    var Powered_by_analytics_bannerpng4: string;
    export default Powered_by_analytics_bannerpng4;
}