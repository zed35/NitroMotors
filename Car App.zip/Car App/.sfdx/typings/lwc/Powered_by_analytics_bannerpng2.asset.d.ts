declare module "@salesforce/contentAssetUrl/Powered_by_analytics_bannerpng2" {
    var Powered_by_analytics_bannerpng2: string;
    export default Powered_by_analytics_bannerpng2;
}