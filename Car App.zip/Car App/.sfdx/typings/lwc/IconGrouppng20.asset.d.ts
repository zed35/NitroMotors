declare module "@salesforce/contentAssetUrl/IconGrouppng20" {
    var IconGrouppng20: string;
    export default IconGrouppng20;
}