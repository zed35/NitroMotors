declare module "@salesforce/contentAssetUrl/customerspng2" {
    var customerspng2: string;
    export default customerspng2;
}