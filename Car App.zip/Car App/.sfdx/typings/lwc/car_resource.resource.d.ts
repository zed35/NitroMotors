declare module "@salesforce/resourceUrl/car_resource" {
    var car_resource: string;
    export default car_resource;
}