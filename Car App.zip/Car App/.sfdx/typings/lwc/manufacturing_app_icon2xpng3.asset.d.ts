declare module "@salesforce/contentAssetUrl/manufacturing_app_icon2xpng3" {
    var manufacturing_app_icon2xpng3: string;
    export default manufacturing_app_icon2xpng3;
}