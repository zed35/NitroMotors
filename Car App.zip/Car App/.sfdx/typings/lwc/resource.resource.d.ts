declare module "@salesforce/resourceUrl/resource" {
    var resource: string;
    export default resource;
}