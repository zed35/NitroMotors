declare module "@salesforce/contentAssetUrl/arrowpngpng1" {
    var arrowpngpng1: string;
    export default arrowpngpng1;
}