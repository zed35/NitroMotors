declare module "@salesforce/contentAssetUrl/thumb2" {
    var thumb2: string;
    export default thumb2;
}