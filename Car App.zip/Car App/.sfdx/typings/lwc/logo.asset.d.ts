declare module "@salesforce/contentAssetUrl/logo" {
    var logo: string;
    export default logo;
}