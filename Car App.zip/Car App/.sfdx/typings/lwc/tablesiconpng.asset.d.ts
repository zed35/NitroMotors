declare module "@salesforce/contentAssetUrl/tablesiconpng" {
    var tablesiconpng: string;
    export default tablesiconpng;
}