declare module "@salesforce/contentAssetUrl/Icon_grouppng1" {
    var Icon_grouppng1: string;
    export default Icon_grouppng1;
}