declare module "@salesforce/contentAssetUrl/tracker_iconpng" {
    var tracker_iconpng: string;
    export default tracker_iconpng;
}