declare module "@salesforce/apex/EmailDealerOfNewBooking.sendEmailNotification" {
  export default function sendEmailNotification(param: {cb: any}): Promise<any>;
}
