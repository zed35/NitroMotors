declare module "@salesforce/apex/SendEmailEveryUpdate.sendEmailNotification" {
  export default function sendEmailNotification(param: {cb: any}): Promise<any>;
}
