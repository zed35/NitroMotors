declare module "@salesforce/apex/digitalMarketingData.getList" {
  export default function getList(): Promise<any>;
}
