declare module "@salesforce/apex/fetchCarModel.getList" {
  export default function getList(param: {searchKey: any}): Promise<any>;
}
