declare module "@salesforce/apex/recentlyLaunchedCarModels.getList" {
  export default function getList(): Promise<any>;
}
