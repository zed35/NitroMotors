declare module "@salesforce/apex/fetchAllCarModelData.getList" {
  export default function getList(): Promise<any>;
}
