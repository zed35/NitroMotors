declare module "@salesforce/apex/fetchNewBooking.getId" {
  export default function getId(): Promise<any>;
}
