declare module "@salesforce/apex/addAccount.setAccount" {
  export default function setAccount(param: {acc: any}): Promise<any>;
}
