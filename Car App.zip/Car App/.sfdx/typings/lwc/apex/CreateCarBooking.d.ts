declare module "@salesforce/apex/CreateCarBooking.createRecord" {
  export default function createRecord(param: {totalPrice: any, carModel: any, requestTD: any, tdPrefDate: any}): Promise<any>;
}
declare module "@salesforce/apex/CreateCarBooking.getId" {
  export default function getId(): Promise<any>;
}
