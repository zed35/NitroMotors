declare module "@salesforce/apex/CarDataController.carDetails" {
  export default function carDetails(): Promise<any>;
}
