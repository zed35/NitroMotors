declare module "@salesforce/apex/FileUploaderClass.uploadFile" {
  export default function uploadFile(param: {base64: any, filename: any, recordId: any}): Promise<any>;
}
