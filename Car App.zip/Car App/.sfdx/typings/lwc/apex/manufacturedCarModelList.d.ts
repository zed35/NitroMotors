declare module "@salesforce/apex/manufacturedCarModelList.getList" {
  export default function getList(): Promise<any>;
}
