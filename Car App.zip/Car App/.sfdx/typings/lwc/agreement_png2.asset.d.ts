declare module "@salesforce/contentAssetUrl/agreement_png2" {
    var agreement_png2: string;
    export default agreement_png2;
}