declare module "@salesforce/contentAssetUrl/Icon_userpng" {
    var Icon_userpng: string;
    export default Icon_userpng;
}