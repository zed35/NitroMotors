declare module "@salesforce/contentAssetUrl/custom109png" {
    var custom109png: string;
    export default custom109png;
}