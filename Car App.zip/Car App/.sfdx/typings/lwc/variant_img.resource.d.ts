declare module "@salesforce/resourceUrl/variant_img" {
    var variant_img: string;
    export default variant_img;
}