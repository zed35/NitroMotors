declare module "@salesforce/contentAssetUrl/Icon_Compare_Tablepng" {
    var Icon_Compare_Tablepng: string;
    export default Icon_Compare_Tablepng;
}