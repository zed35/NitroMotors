declare module "@salesforce/contentAssetUrl/thumb1" {
    var thumb1: string;
    export default thumb1;
}