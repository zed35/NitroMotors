declare module "@salesforce/contentAssetUrl/tracker_iconpng1" {
    var tracker_iconpng1: string;
    export default tracker_iconpng1;
}