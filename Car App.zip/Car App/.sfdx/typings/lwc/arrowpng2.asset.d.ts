declare module "@salesforce/contentAssetUrl/arrowpng2" {
    var arrowpng2: string;
    export default arrowpng2;
}