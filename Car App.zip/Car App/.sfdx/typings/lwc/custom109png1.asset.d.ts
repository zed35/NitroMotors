declare module "@salesforce/contentAssetUrl/custom109png1" {
    var custom109png1: string;
    export default custom109png1;
}