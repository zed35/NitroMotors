declare module "@salesforce/contentAssetUrl/Astro_1png" {
    var Astro_1png: string;
    export default Astro_1png;
}