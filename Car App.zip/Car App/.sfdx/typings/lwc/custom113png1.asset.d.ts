declare module "@salesforce/contentAssetUrl/custom113png1" {
    var custom113png1: string;
    export default custom113png1;
}