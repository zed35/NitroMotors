declare module "@salesforce/contentAssetUrl/bgpng" {
    var bgpng: string;
    export default bgpng;
}