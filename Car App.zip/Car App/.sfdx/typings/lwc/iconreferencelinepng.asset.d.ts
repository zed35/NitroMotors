declare module "@salesforce/contentAssetUrl/iconreferencelinepng" {
    var iconreferencelinepng: string;
    export default iconreferencelinepng;
}