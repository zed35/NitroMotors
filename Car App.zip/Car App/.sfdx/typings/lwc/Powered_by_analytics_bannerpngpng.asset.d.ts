declare module "@salesforce/contentAssetUrl/Powered_by_analytics_bannerpngpng" {
    var Powered_by_analytics_bannerpngpng: string;
    export default Powered_by_analytics_bannerpngpng;
}