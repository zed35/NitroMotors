declare module "@salesforce/resourceUrl/siteAsset_abea847fee5648e1902af9c62886f022" {
    var siteAsset_abea847fee5648e1902af9c62886f022: string;
    export default siteAsset_abea847fee5648e1902af9c62886f022;
}