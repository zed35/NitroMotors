declare module "@salesforce/contentAssetUrl/IconUserpng32" {
    var IconUserpng32: string;
    export default IconUserpng32;
}