declare module "@salesforce/contentAssetUrl/Backgroundpng" {
    var Backgroundpng: string;
    export default Backgroundpng;
}