declare module "@salesforce/contentAssetUrl/graph2xpng3" {
    var graph2xpng3: string;
    export default graph2xpng3;
}