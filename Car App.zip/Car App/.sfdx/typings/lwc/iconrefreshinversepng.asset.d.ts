declare module "@salesforce/contentAssetUrl/iconrefreshinversepng" {
    var iconrefreshinversepng: string;
    export default iconrefreshinversepng;
}