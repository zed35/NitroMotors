declare module "@salesforce/contentAssetUrl/money_bag_png3" {
    var money_bag_png3: string;
    export default money_bag_png3;
}