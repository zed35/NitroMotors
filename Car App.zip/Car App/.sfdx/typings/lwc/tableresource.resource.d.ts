declare module "@salesforce/resourceUrl/tableresource" {
    var tableresource: string;
    export default tableresource;
}