declare module "@salesforce/contentAssetUrl/logo1" {
    var logo1: string;
    export default logo1;
}