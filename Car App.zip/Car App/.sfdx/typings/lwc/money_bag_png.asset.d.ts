declare module "@salesforce/contentAssetUrl/money_bag_png" {
    var money_bag_png: string;
    export default money_bag_png;
}