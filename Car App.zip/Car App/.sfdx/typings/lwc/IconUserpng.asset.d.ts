declare module "@salesforce/contentAssetUrl/IconUserpng" {
    var IconUserpng: string;
    export default IconUserpng;
}