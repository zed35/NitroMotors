declare module "@salesforce/contentAssetUrl/IconUserpng3" {
    var IconUserpng3: string;
    export default IconUserpng3;
}